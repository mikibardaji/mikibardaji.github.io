
import java.util.*;
import java.io.*;
/**
 * ContactObjectStream.java
 *
 * @author ProvenSoft
 */
public class ContactObjectStream {

    private static final String FILE_NAME = "phonebook.txt";
	private static List<Contact> phbk;
	
    public ContactObjectStream() {
		phbk = new ArrayList<>();
    }
    
    public static void main(String[] args) {
    	ContactObjectStream app = new ContactObjectStream();
        //populate list
        phbk.add(new Contact("Peter","555111111",25));
        phbk.add(new Contact("Mary","555222222",33));
        phbk.add(new Contact("Angie","555333333",27));
        phbk.add(new Contact("Mark","555444444",42));
        phbk.add(new Contact("Ann","555555555",29));
        //display list
        app.showPhoneBook(phbk);
        //save list to file
        app.savePhoneBook(phbk);
        //read list from file
        List<Contact> copia =app.readPhoneBook();
        if (copia != null) {
			//display read list
			app.showPhoneBook(copia);			
		}
    }
    
    /**
     * Prints the list of contacts passed as a parameter to the console
     * @param pb List of contacts
     */
    private void showPhoneBook(List<Contact> pb)
    {
    	for (Contact c: pb)
    	{
    		System.out.println(c.toString());
    	}
    }
    
    /**
     * Stores the phonebook to a file
     * @param pb list of contacts
     */
    private void savePhoneBook(List<Contact> pb)
    {
    	System.out.println("Saving phonebook ...");
    	int i=0;
    	try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
	    
	    	for (Contact c: pb)
	    	{
	    		oos.writeObject(c);
	    		i++;
	    	}
	    	System.out.println(i+" contacts have been written to file "+FILE_NAME+".");
    	}
    	catch (FileNotFoundException fnfe) {
    		System.out.println("File not found: "+fnfe.getMessage());
    	}
    	catch (IOException ioe) {
    		System.out.println("Output error: "+ioe.getMessage());
    	}
    }
    
    /**
     * Reads a list of contacts from a file
     * @return a list of contacts
     */
    private List<Contact> readPhoneBook() {
        
        System.out.println("Reading phonebook ...");

        List<Contact> pb = new ArrayList<>();
        int i=0;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            Object obj;
            while ( ( obj=ois.readObject() ) != null)
            {
                if ( obj instanceof Contact )
                {
                    Contact p = (Contact) obj;
                    pb.add(p);
                    i++;
                }
            }
        }
        catch (EOFException eofe) { 	}
        catch (FileNotFoundException fnfe) {
                System.out.println("File not found: "+fnfe.getMessage());
                pb=null;
        }
        catch (IOException ioe) {
                System.out.println("Input error: "+ioe.getMessage());
                pb=null;
        }
        finally {
                System.out.println(i+" contacts have been read from file "+FILE_NAME+".");
                return pb;
        }
    }
}
