/**
 * PropertyNotInitializedException.java
 * PropertyNotInitializedException class
 * @author Jose
 * @version 
 */
 public class PropertyNotInitializedException extends Exception {
	public PropertyNotInitializedException(String msg) {
		super(msg);						
	}
}
