/**
 * InvalidValueException.java
 * InvalidValueException class
 * @author Jose
 * @version 
 */
 public class InvalidValueException extends Exception {
	public InvalidValueException(String msg) {
		super(msg);						
	}
}
