import java.io.*;
import java.util.*;
/**
 * Example of Properties class.
 */
public class PropertiesExample {

    public static void main(String args[]) {
        /* Name of file containing the properties */
        String configFileName = "PropertiesExample01.properties";
        /* Properties object */
        Properties props = new Properties();
        try {
            /* Read the properties from the file */
            props.load(new FileInputStream(configFileName));
            /* display the properties */
            props.list(System.out);
            /* Input the username and the password */
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(System.in));
            System.out.print("Input the username: ");
            String uname = reader.readLine();
            System.out.print("Input the password: ");
            String pword = reader.readLine();
            /* Check if username and password are ok */
            if ((uname.equals(props.getProperty("username")))
                    && (pword.equals(props.getProperty("password")))) {
                System.out.println("Login OK");
                System.out.print("Do you want to change your password? (Y/N)");
                String change = reader.readLine();
                if (change.equals("Y")) {
                    Console cons = System.console();
                    System.out.print("Input new password: ");
                    //String psw1 = reader.readLine();
                    String psw1 = new String(cons.readPassword());
                    System.out.print("Retype new password: ");
                    //String psw2 = reader.readLine();
                    String psw2 = new String(cons.readPassword());
                    if (psw1.equals(psw2)) {
                        props.setProperty("password", psw1);
                        System.out.println("Password changed. Remember it!");
                        props.list(System.out);
                    } else {
                        System.out.println("Passwords are not equal!");
                    }
                } else {
                    System.out.println("Goodbye");
                }
            } else {
                System.out.println("Login failed. Username or password incorrect.");
            }
            props.store(new FileOutputStream(configFileName), "Config file");
        } catch (IOException ioe) {
            System.out.println("Error reading config file." + ioe.getMessage());
        }
    }
}
