import java.util.*;
/**
 * ClientManagerAp.java
 * Application to manage a list of clients.
 * @author Jose.
 */
public class ClientManagerAp {
	
	private List<Client> myClients = new ArrayList<Client>();
	
	public static void main (String args[]) {
		Menu mainMenu = buildMainMenu();  //main menu of our application.
		boolean exit = false;  //flag to exit application.
		int optionSelected;
		ClientManagerAp clientManager = new ClientManagerAp();
		
		// load initial data.
		clientManager.loadClients();
		
		do {
			
			mainMenu.show();
			System.out.print("Choose an option: ");
			optionSelected = mainMenu.choose();
			
			switch (optionSelected) {
				case 0: //exit application.
					exit = true;
					break;
				case 1: //find a client by id.
					clientManager.findAClientById();
					break;
				case 2: //list all clients.
					clientManager.listAllClients();
					break;
				case 3: //add a new client.
					clientManager.addANewClient();
					break;
				case 4: //modify a client.
					clientManager.modifyAClient();
					break;
				case 5: //remove a client.
					clientManager.removeAClient();
					break;
				default:
					System.out.println("Invalid option");
					break;
			}
			
		} while (!exit);
		
		// save final data.
		clientManager.saveClients();
		System.out.println("Exitting application");
		
	}
	
	/** buildMainMenu()
	 * Builds and returns the main menu of our application.
	 */
	private static Menu buildMainMenu() {
		Menu mnu = new Menu("Client manager application");
		mnu.add( new Option("Exit") );
		mnu.add( new Option("Find a client by id") );
		mnu.add( new Option("List all clients") );
		mnu.add( new Option("Add a new client") );
		mnu.add( new Option("Modify a client") );
		mnu.add( new Option("Remove a client") );
		return mnu;
	}
	
	/** 
	 * Ask the user for a client id and searches for him in the list.
	 */
	private void findAClientById() {
		// TODO
		System.out.println("Searching client...");
	}

	/** 
	 * Shows the list of clients.
	 */
	private void listAllClients() {
		System.out.println("Listing all clients...");
		ListIterator<Client> it = myClients.listIterator();
		while (it.hasNext()) {
			Client c = it.next();
			System.out.println(c.toString());
		}
		System.out.format("%d clients found.\n", myClients.size());
	}

	/** 
	 * Adds a new client to the list.
	 * First, it asks for the new client data to the user,
	 * creates a new client with that data,
	 * and add the new client to the list.
	 */
	private void addANewClient() {
		System.out.println("Adding a new client...");
		Client cli = readClient();
		if (cli != null) {
			System.out.println("Adding the new client to the list");
			myClients.add(cli);
		}
		else System.out.println("Client not added. Error in input data");
	}

	/** 
	 * Modifies a client.
	 * First, it asks the client id,
	 * then, it look him up in the list.
	 * If found, it shows the actual client information and ask for new data.
	 * Finally, it modifies the client.
	 * If not found, it reports the error to the user.
	 */
	private void modifyAClient() {
		// TODO
		System.out.println("Modifying a client...");
	}
	
	/** 
	 * Removes a client.
	 * First, it asks the client id,
	 * then, it look him up in the list.
	 * If found, it shows the actual client information and ask for confirmation.
	 * After comfirmed, it removes the client.
	 * If not found, it reports the error to the user.
	 */
	private void removeAClient() {
		// TODO
		System.out.println("Removing a client...");
	}

	/** readClient()
	 * Read from user a client data.
	 * @return client object with inputted data or null if an error occurs.
	 */
	private Client readClient() {
		// TODO
		System.out.println("Reading client data...");
		return null; 
		//return new Client();
	}	
	
	/** 
	 * Loads initial data into client list.
	 */
	private void loadClients() {
		System.out.println("Loading client data into list of clients...");
		myClients.add( new Client("001A", "Peter", "93001", "Addr01", 1001.0) );
		myClients.add( new Client("001B", "Paul", "93002", "Addr02", 1002.0) );
		myClients.add( new Client("001C", "Mary", "93003", "Addr03", 1003.0) );
		myClients.add( new Client("001D", "Bob", "93004", "Addr04", 1004.0) );
		myClients.add( new Client("001E", "Sophie", "93005", "Addr05", 1005.0) );
		myClients.add( new Client("001F", "Andrew", "93006", "Addr06", 1006.0) );
		myClients.add( new Client("001G", "Phil", "93007", "Addr07", 1007.0) );
	}	
	
	/** 
	 * Saves client data to persistent media.
	 */
	private void saveClients() {
		// TODO
		System.out.println("Saving client list data...");
	}	
}










