package parlador;

/**
 *
 * @author Jose
 */
public interface Parlador {
    void parla();
}
