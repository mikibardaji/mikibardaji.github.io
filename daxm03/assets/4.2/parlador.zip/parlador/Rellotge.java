package parlador;

/**
 *
 * @author Jose
 */
public abstract class Rellotge implements Parlador {
    
}
