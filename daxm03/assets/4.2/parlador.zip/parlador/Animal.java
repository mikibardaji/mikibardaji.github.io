package parlador;

/**
 *
 * @author Jose
 */
public abstract class Animal implements Parlador {
    //public abstract void parla();
}
