package parlador;

/**
 *
 * @author Jose
 */
public class Cucut extends Rellotge {

    @Override
    public void parla() {
        System.out.println("Cucut!");
    }
    
}
