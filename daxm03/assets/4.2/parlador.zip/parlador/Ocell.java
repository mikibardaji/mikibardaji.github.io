package parlador;

/**
 *
 * @author Jose
 */
public class Ocell extends Animal {

    @Override
    public void parla() {
        System.out.println("Piu!");
    }
    
}
