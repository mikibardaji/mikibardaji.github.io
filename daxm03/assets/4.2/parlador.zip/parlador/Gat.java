package parlador;

/**
 *
 * @author Jose
 */
public class Gat extends Animal {

    @Override
    public void parla() {
        System.out.println("Meu!");
    }
    
}
