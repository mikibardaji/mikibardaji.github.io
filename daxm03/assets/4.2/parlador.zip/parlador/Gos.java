package parlador;

/**
 *
 * @author Jose
 */
public class Gos extends Animal {

    @Override
    public void parla() {
        System.out.println("Guau!");
    }
    
}
