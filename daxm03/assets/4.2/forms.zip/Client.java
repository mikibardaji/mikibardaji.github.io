/**
 * Client.java
 * ADT client.
 * @author Jose Moreno
 * @version 
 */

public class Client implements Entity {
	private int id;
	private String name;

	public Client(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId(){
		return id;
	}

	public void setId(int id){
		this.id = id;
	}
	
	public String getName(){
		return name;
	}

	public void setName(String name){
		this.name = name;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{Client: ");
		sb.append("id="); sb.append(id);
		sb.append("; name="); sb.append(name);
		sb.append("}");
		return sb.toString();
	}
	
}
