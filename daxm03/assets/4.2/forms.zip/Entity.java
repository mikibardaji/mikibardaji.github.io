/**
 * Entity.java
 * Entity interface. Should be implemented by model classes.
 * @author Jose Moreno
 * @version 
 */

public interface Entity {
	
}
