/**
 * Product.java
 * ADT product.
 * @author Jose Moreno
 * @version 
 */

public class Product implements Entity {
	private int id;
	private String description;

	public Product(int id, String description) {
		this.id = id;
		this.description = description;
	}

	public int getId(){
	  	return id;
	}
	 
	public void setId(int id){
	 	this.id = id;
	}

	public String getDescription(){
		return description;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{Product: ");
		sb.append("id="); sb.append(id);
		sb.append("; description="); sb.append(description);
		sb.append("}");
		return sb.toString();
	}
	
}
