/**
 * Forms.java
 * Version of Factory method pattern to implement forms to input data.
 * @author Jose Moreno
 * @version 
 */

import java.util.Scanner;
import java.util.InputMismatchException;

public class Forms {

 	/**
 	 * entityForm()
 	 * form to input a generic entity
 	 * @param Entity entity: entity object with initial data (its contents are not used here)
 	 * @return Entity with entered data or null in case of input error
 	 */
  public static Entity entityForm(Entity entity) {
 		Class c = entity.getClass(); //get the entity class.
 		String className = c.getSimpleName();  //get the class simple name.
 		Entity retEntity = null;
 		switch (className) {
 			case "Product":
 				retEntity = entityForm((Product)entity);
 				break;
 			case "Client":
 				retEntity = entityForm((Client)entity);
 				break;
 			default:  //any form for that object.
 				retEntity = null;
 		}
 		return retEntity;
 	}

 	/**
 	 * entityForm()
 	 * form to input a client entity
 	 * @param Client entity: entity object with initial data
 	 * @return Entity with entered data or null in case of input error.
 	 */
 	public static Entity entityForm(Client entity) {
    System.out.println("========= Client form ===========");
    System.out.println("Actual data: "+entity.toString());
 		Client retEntity = null;
 		try {
 			int id = inputInt("Input id: ");
 			String name = inputString("Input name: ");
 			retEntity = new Client(id, name);
 		} catch (InputMismatchException e) {
 			retEntity = null;
 		}
 		return retEntity;
 	}

  /**
 	 * entityForm()
 	 * form to input a product entity
 	 * @param Product entity: entity object with initial data
 	 * @return Entity with entered data or null in case of input error.
 	 */
  	public static Entity entityForm(Product entity) {
    System.out.println("========= Product form ===========");
    System.out.println("Actual data: "+entity.toString());
 		Product retEntity = null;
 		try {
 			int id = inputInt("Input id: ");
 			String description = inputString("Input description: ");
 			retEntity = new Product(id, description);
 		} catch (InputMismatchException e) {
 			retEntity = null;
 		}
  		return retEntity;
 	}

  /**
   * alert()
   * convenience utility method to show a message
   * @param String msg: message to be shown to user.
   */
  public static void alert(String msg) {
      System.out.print(msg);
  }

  /**
   * inputString()
   * convenience utility method to input a String
   * @param String msg: message to be shown to user.
   * @return String: value entered.
   */
    public static String inputString(String msg) {
      Scanner scan = new Scanner(System.in);
      System.out.print(msg);
      String value = scan.next();
      return value;
  }

  /**
 	 * inputInt()
 	 * convenience utility method to input an integer
 	 * @param String msg: message to be shown to user.
 	 * @return int: value entered.
 	 */
 	public static int inputInt(String msg) throws InputMismatchException {
  		Scanner scan = new Scanner(System.in);
  		System.out.print(msg);
  		int value = scan.nextInt();
  		return value;
 	}

  /**
   * inputDouble()
   * convenience utility method to input a double
   * @param String msg: message to be shown to user.
   * @return double: value entered.
   */
  public static double inputDouble(String msg) throws InputMismatchException {
      Scanner scan = new Scanner(System.in);
      System.out.print(msg);
      double value = scan.nextDouble();
      return value;
  }

 }
