/**
 * FormsMain.java
 * Demostration of using of Forms class 
 * @author Jose Moreno
 * @version 
 */

public class FormsMain {

	public static void main(String [] args) {

		Product e1 = new Product(1, "TV");
		Client e2 = new Client(1, "Peter");
		Entity e3 = null;

		e1 = (Product) Forms.entityForm(e1);
		e2 = (Client) Forms.entityForm(e2);
		e3 = e1;
		Entity e4 = Forms.entityForm(e3);
		e3 = e2;
		Entity e5 = Forms.entityForm(e3);

		System.out.println("e1: "+e1.toString());
		System.out.println("e2: "+e2.toString());
		System.out.println("e4: "+e4.toString());
		System.out.println("e5: "+e5.toString());

	}

}
