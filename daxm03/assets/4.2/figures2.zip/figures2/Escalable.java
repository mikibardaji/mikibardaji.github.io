package figures2;

/**
 *
 * @author Jose
 */
public interface Escalable {
    public void escalar(double factor);
}
