package figures2;

/**
 *
 * @author Jose
 */
public interface Mesurable {
    public double perimetre();
}
