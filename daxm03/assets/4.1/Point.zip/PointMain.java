/**
 * Test class for Point class.
 */
public class PointMain {
	
	public static void main (String args[]) {
		//instantiate two points.
		Point a = new Point(3.0, 2.0);
		Point b = new Point();
		//show the points.
		System.out.println("Initial values");
		System.out.println("a="+a.toString());
		System.out.println("b="+b.toString());
		System.out.println("Changed values");
		//change points.
		//first test with direct assignment, using public access modifiers.
		//a.x = -1.0;
		//b.y = 4.0;
		//change to private access modifiers and use accessor methods.
		a.setX(-1.0);
		b.setY(4.0);
		System.out.println("a="+a.toString());
		System.out.println("b="+b.toString());
		//instantiate new point and calculate distances.
		Point c = new Point(5.0, 4.0);
		//System.out.println("Distance from a to c="+a.distanceTo(c));			
		System.out.format("Distance from a to c=%.2f\n", a.distanceTo(c));
		//test equals() method.
		if (a.equals(c)) System.out.println("a=c");
		else System.out.println("a!=c");
		Point d = new Point(5.0, 4.0);
		if (d.equals(c)) System.out.println("d=c");
		else System.out.println("d!=c");
		//test copy constructor.
		System.out.println("Use copy constructor");
		Point e = new Point(a);	
		System.out.println("e="+e.toString());
		//what if references are assigned and changes are made through one of them?.
		Point f = e;
		System.out.println("f="+f.toString());
		f.setY(-2);
		System.out.println("e="+e.toString());
		System.out.println("f="+f.toString());						
	}
}

