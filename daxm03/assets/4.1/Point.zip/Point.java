/**
 * Point.java
 * Class Point: encapsulates points in two dimensions.
 */
public class Point {
	
/* ============== Attributes ================*/
    private double x;  //x coordinate of the point. (R/W)
    private double y;  //y coordinate of the point. (R/W)
    
/* ============== Constructors ==============*/
	/**
	 * Initialization constructor.
	 * @param double x: x coordinate.
	 * @param double y: y coordinate.
	 */
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Default constructor. It initializes coordinates to 0.
	 * @param none
	 */
	public Point() {
		x = 0.0;
		y = 0.0;
	}
	
	/**
	 * Copy constructor.
	 * @param Point p.
	 */
	public Point(Point other) {
		this.x = other.x;
		this.y = other.y;
	}	
	
/* ============== Accessors ================*/

	/**
	 * getX()
	 * read accessor.
	 * @param none.
	 * @return double: value of attribute x.
	 */
	public double getX() {
		return x;
	}
	
	/**
	 * write accessor.
	 * @param double x: value to set to attribute x.
	 * @return nothing.
	 */
	public void setX(double x) {
		this.x = x;
	}
	
	/**
	 * read accessor.
	 * @param none.
	 * @return double: value of attribute y.
	 */
	public double getY() {
		return y;
	}
	
	/**
	 * write accessor.
	 * @param double y: value to set to attribute y
	 * @return nothing.
	 */
	public void setY(double y) {
		this.y = y;
	}
	
/* ============== Methods ================*/
	
	/**
	 * calculates and returns the distance from this point to another.
	 * @param Point other: destination point.
	 * @return distance from this point to point other.
	 */
	public double distanceTo(Point other) {
		return (Math.hypot(other.x - x, other.y - y));
	}
		
	/**
	 * Compares this point to another. 
	 * Two points are equal if and only if x-coordinates are equal to
	 * each other and y-coordinates are equal to each other.
	 * @param Object p: second point to be compared with this.
	 * @return true if two points are equal, false otherwise.
	 */
	public boolean equals(Object obj) {
	    boolean b=false;
		if (obj == null) b = false;  //object is null.
		else {
			if (this == obj) b = true;  //same object.
			else {
				if (obj instanceof Point) {  //obj is Point
					Point other = (Point) obj;
					b = (x == other.x) && (y == other.y);
				}
				else b = false;  //obj is not an Point
			}
		}		
		return b;
	}
	
	/**
	 * toString()
	 * builds a String representation of the object.
	 * @param none
	 * @return a String representing the object.
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Point{");
		sb.append( String.format("[x=%f]", x) );
		sb.append( String.format("[y=%f]", y) );
		sb.append("}");	
		return sb.toString();
	}
	
}

