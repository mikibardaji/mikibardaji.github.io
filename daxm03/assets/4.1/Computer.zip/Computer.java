/**
 *	TAD Computer
 */
public class Computer {
	/* attributes or properties or fields (state) */
	private String processor;
	private String memory;
	private String display;
	private boolean switchedOn;
	private boolean screenSaverOn;
	
	/* constructors */
	public Computer(String processor, String memory, String display) {
		setProcessor(processor);
		setMemory(memory);
		setDisplay(display);
		switchedOn = false;
		screenSaverOn = false;
	}

	/* accessors */
	public String getProcessor() { return processor; }
	public void setProcessor(String processor) { this.processor = processor; }
	public String getMemory() { return memory; }
	public void setMemory(String memory) { this.memory = memory; }
	public String getDisplay() { return display; }	
	public void setDisplay(String display) { this.display = display; }
	
	/** isSwitchedOn()
	 * checks if computer is switched on 
	 * @return switchedOn
	 */
	public boolean isSwitchedOn() {
		return switchedOn;
	}
	/** isScreenSaverOn()
	 * checks if computer screensaver is on 
	 * @return screenSaverOn
	 */
	public boolean isScreenSaverOn() {
		return screenSaverOn;
	}
	
	/* methods (behaviour) */
	
	/** switchOn()
	 * switches the computer on
	 * @return nothing
	 */
	public void switchOn() {
		if (!isSwitchedOn()) {
			switchedOn = true;
			System.out.println("Computer is now on");
		}
		else {
			System.out.println("Computer was already on");
		}
	}
	
	/** switchOff()
	 * switches the computer off
	 * @return nothing
	 */
	public void switchOff() {
		if (isSwitchedOn()) {
			screenSaverOn = false;
			switchedOn = false;
			System.out.println("Computer is now off");
		}
		else {
			System.out.println("Computer was already off");
		}
	}
	
	/** setScreenSaverOn()
	 * switches the computer screensaver on
	 * @return nothing
	 */
	public void setScreenSaverOn() {
		if (isSwitchedOn()) {
			if (!isScreenSaverOn()) {
				screenSaverOn = true;
				System.out.println("Screensaver is now on");
			}
			else {
				System.out.println("Screensaver was already on");
			}
		}
		else {
			System.out.println("Computer is off");
		}
	}
	
	/** setScreenSaverOff()
	 * switches the computer screensaver off
	 * @return nothing
	 */
	public void setScreenSaverOff() {
		if (isSwitchedOn()) {
			if (isScreenSaverOn()) {
				screenSaverOn = false;
				System.out.println("Screensaver is now off");
			}
			else {
				System.out.println("Screensaver was already off");
			}
		}
		else {
			System.out.println("Computer is off");
		}		
	}
}
