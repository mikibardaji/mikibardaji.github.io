/** 
 * Main class for computer class testing with a menu for the user
 */
import java.util.Scanner;
import java.util.InputMismatchException;

 public class ComputerMain {
	 static class Menu {
		 String [] menuItems = {
			 "Exit", "Switch on computer", "Switch off computer",
			 "Switch on screensaver", "Switch off screen saver" 
			};
		public void show() {
			System.out.println("=======Computers menu=======");
			for (int i=0; i<menuItems.length; i++) {
				System.out.println(Integer.toString(i)+".-"+menuItems[i]);
			}
			System.out.println("============================");
		}
		public int readOption() {
			int option=-1;
			Scanner scan = new Scanner(System.in);
			try {
				option = scan.nextInt();
			} catch (InputMismatchException ime) {
				ime.printStackTrace();
			}
			return option;
		}
	}
	public static void main(String [] args) {
		Menu appMenu = new Menu();
		Computer myComputer = new Computer("Pentium I5", "4GB", "LCD 21");
		boolean exit=false;
		int option;
		do {
			appMenu.show();
			option = appMenu.readOption();
			switch (option) {
				case 0: //exit
					exit = true;
					break;
				case 1: //Switch on computer
					//if (!myComputer.isSwitchedOn()) 
						myComputer.switchOn();
					break;
				case 2: //Switch off computer
					//if (myComputer.isSwitchedOn()) 
						myComputer.switchOff();
					break;
				case 3: //Switch on computer screensaver
					//if (!myComputer.isScreenSaverOn())
						myComputer.setScreenSaverOn();
					break;
				case 4: //Switch off computer screensaver
					//if (myComputer.isScreenSaverOn()) 
						myComputer.setScreenSaverOff();
					break;
				default: //invalid option
					System.out.println("Invalid option");
					break;
			}	
		} while (!exit);
		System.out.println("Goodbye");
	}
}
