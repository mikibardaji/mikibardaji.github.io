/**
* Rectangle.java
* TAD Rectangle
*/
public class Rectangle {
	//Propietats o atributs
	private double base;
	//base del rectangle (lectura/escriptura)
	private double altura; //altura del rectangle (lectura/escriptura)
	/**
	* Contructor per defecte (sense parametres)
	**/
	public Rectangle() {
		base = 0.0;
		altura = 0.0;
	}
	/**
	* Contructor amb inicialització
	**/
	public Rectangle(double base, double altura) {
		setBase(base);
		setAltura(altura);
	}
	
	/**
	 * constructor de còpia
	 */
	public Rectangle(Rectangle other) {
		setBase(other.base);
		setAltura(other.altura);
	}
	
	//accessors
	public double getBase() {
		return base;
	}
	public void setBase(double base) {
		if (base>=0) this.base = base;
		else this.base = 0;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		if (altura >= 0) this.altura = altura;
		else this.altura = 0;
	}
		
	//Comportament (mètodes)
	
	/** 
	* @return area del rectangle
	*/
	public double area() {
		return ( base*altura );
	}
	/** 
	* @return perimetre del rectangle
	*/
	public double perimetre() {
		return ( 2*(base+altura) );
	}
	/** 
	* @return conversió a String del rectangle
	*/
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Rectangle{");
		sb.append( String.format("[base=%f]", base) );
		sb.append( String.format("[altura=%f]", altura) );
		sb.append("}");	
		return sb.toString();
	}
	/** 
	* @return comparació amb un altre Rectangle
	*/
	public boolean equals(Object other) {
	    boolean b=false;
		if (obj == null) b = false;  //object is null.
		else {
			if (this == obj) b = true;  //same object.
			else {
				if (obj instanceof Point) {  //obj is Rectangle
					Rectangle other = (Rectangle) obj;
					b = (base == other.base) && (altura == other.altura);
				}
				else b = false;  //obj is not an Rectangle
			}
		}		
		return b;
	}
}
