import java.io.*;
/**
* RectangleMain.java
* Aplicació de càlcul amb rectangles
*/
public class RectangleMain {
	public RectangleMain() {
	}
	public static void main(String[] args) {
		Rectangle a = new Rectangle();
		Rectangle b = new Rectangle(5.0, 2.0);
		Rectangle c = new Rectangle(3.0, 4.0);
		System.out.println("Mostrem amb toString()");
		System.out.println("Rectangle a: "+a.toString());
		System.out.println("Rectangle b: "+b.toString());
		System.out.println("Rectangle c: "+c.toString());
		System.out.println("Mostrem perimetres i arees");
		System.out.println("El rectangle a te perimetre="+a.perimetre()+" i area="+a.area());
		System.out.println("El rectangle b te perimetre="+b.perimetre()+" i area="+b.area());
		System.out.println("El rectangle c te perimetre="+c.perimetre()+" i area="+c.area());
		System.out.println("Comparacions");
		if ( a.equals(b) ) System.out.println("Els rectangles a i b són iguals");
		else System.out.println("Els rectangles a i b són diferents");
		System.out.println("Canviem el rectangle b");
		//b.base = -4;
		b.setBase(-4);
		System.out.println("Rectangle b: "+b.toString());
		System.out.println("El rectangle b te perimetre="+b.perimetre()+" i area="+b.area());
	}
}
