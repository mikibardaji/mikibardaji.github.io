/**
 * Sphere.java
 *	TAD Sphere
 */
public class Sphere {
	/* attributes or properties or fields (state) */
	/* the radius of the sphere */ /* reading and writing property */
	private double radius;
	/* constructors */
	public Sphere(double radius) {
		setRadius(radius);
	}
	public Sphere() {
		setRadius(0.0);
	}
	public Sphere(Sphere sp) {
		setRadius(sp.radius);
	}
	/* Accessors */
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		if (radius >=0) this.radius = radius;
		else this.radius = 0.0;
	}
	
	/* methods (behaviour) */
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Sphere{");
		sb.append( String.format("[radious=%f]", radious) );
		sb.append("}");	
		return sb.toString();
	}
	
	public boolean equals(Object sp) {
	    boolean b=false;
		if (obj == null) b = false; 
		else {
			if (this == obj) b = true; 
			else {
				if (obj instanceof Point) { 
					Sphere other = (Sphere) obj;
					b = (radious == other.radious);
				}
				else b = false; 
			}
		}		
		return b;
	}
    /** area()
    * calculates sphere area
    * @return calculated area
    */
    public double area() {
        return 4.0*Math.PI*radius*radius;
    }
     /** volume()
    * calculates sphere volume
    * @return calculated volume
    */
    public double volume()  {
        return 4.0/3.0*Math.PI*radius*radius*radius;
    }
}
