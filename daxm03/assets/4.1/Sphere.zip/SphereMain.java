/** 
* Sphere area and volume calculation
*/
import java.io.*;
public class SphereMain {
    public static void main(String args[]) {
       /* radius of the sphere */
       double radius;
       System.out.print("Input radius: ");
       try {
           /* Reader from console */
            BufferedReader reader = new BufferedReader (
				new InputStreamReader(System.in) );
            /* read and convert to double */
            radius = Double.parseDouble(reader.readLine());
            System.out.println("radius="+radius);
            /* create new Sphere */
            Sphere mySphere = new Sphere(radius);
            /* area of the sphere */
			double area = mySphere.area();
            /* volume of the sphere */
			double volume = mySphere.volume();
            /* show area */
			System.out.println("Sphere area="+area);
            /* show volume */
			System.out.println("Sphere volume="+volume);
			/* include a rectangle */
			Rectangle myRectangle = new Rectangle(3.0, 2.0);
			System.out.println("Rectangle area="+myRectangle.area());
         } catch (NumberFormatException nfe) {
            //e.printStackTrace();
            System.out.println("Invalid input data");
		 } catch (IOException ioe) {
			 System.out.println("Error in input");
		 }
    }   
 }
